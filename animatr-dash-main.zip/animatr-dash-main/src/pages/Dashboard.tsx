import { Users, TrendingUp, DollarSign, Activity } from "lucide-react";
import { DashboardWidget } from "@/components/dashboard/DashboardWidget";
import { UserActivityChart, RevenueChart, UserRolesChart } from "@/components/dashboard/AnalyticsChart";
import { UserTable } from "@/components/dashboard/UserTable";

export default function Dashboard() {
  return (
    <div className="space-y-6 animate-fade-in">
      {/* Metrics Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <DashboardWidget
          title="Total Users"
          value="2,847"
          change="+12%"
          changeType="positive"
          description="from last month"
          icon={Users}
          delay={0}
        />
        <DashboardWidget
          title="Revenue"
          value="$45,231"
          change="+8%"
          changeType="positive"
          description="from last month"
          icon={DollarSign}
          delay={100}
        />
        <DashboardWidget
          title="Active Sessions"
          value="1,423"
          change="+5%"
          changeType="positive"
          description="from last hour"
          icon={Activity}
          delay={200}
        />
        <DashboardWidget
          title="Growth Rate"
          value="23.5%"
          change="-2%"
          changeType="negative"
          description="from last week"
          icon={TrendingUp}
          delay={300}
        />
      </div>

      {/* Charts Grid */}
      <div className="grid gap-6 lg:grid-cols-2">
        <UserActivityChart delay={400} />
        <RevenueChart delay={500} />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <UserTable delay={600} />
        </div>
        <UserRolesChart delay={700} />
      </div>
    </div>
  );
}