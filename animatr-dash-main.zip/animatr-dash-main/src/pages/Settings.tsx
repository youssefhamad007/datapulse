import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Settings as SettingsIcon, 
  Bell, 
  Shield, 
  Palette, 
  Users, 
  Database,
  Mail,
  Globe,
  Download,
  Trash2
} from "lucide-react";

export default function Settings() {
  const { toast } = useToast();

  const handleSave = (setting: string) => {
    toast({
      title: "Settings updated",
      description: `${setting} has been updated successfully.`,
    });
  };

  const handleExport = () => {
    toast({
      title: "Data export",
      description: "Your data export will be ready shortly.",
    });
  };

  const handleClearCache = () => {
    toast({
      title: "Cache cleared",
      description: "Application cache has been cleared successfully.",
    });
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">
          Manage your application preferences and configurations.
        </p>
      </div>

      <div className="grid gap-6">
        {/* General Settings */}
        <Card className="glass border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <SettingsIcon className="h-5 w-5" />
              General
            </CardTitle>
            <CardDescription>
              Basic application settings and preferences.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Dark Mode</Label>
                <p className="text-sm text-muted-foreground">
                  Toggle between light and dark themes
                </p>
              </div>
              <Switch defaultChecked onCheckedChange={() => handleSave("Dark mode")} />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Auto-save</Label>
                <p className="text-sm text-muted-foreground">
                  Automatically save changes as you work
                </p>
              </div>
              <Switch defaultChecked onCheckedChange={() => handleSave("Auto-save")} />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Sidebar collapsed by default</Label>
                <p className="text-sm text-muted-foreground">
                  Start with sidebar in collapsed state
                </p>
              </div>
              <Switch onCheckedChange={() => handleSave("Sidebar state")} />
            </div>
          </CardContent>
        </Card>

        {/* Notification Settings */}
        <Card className="glass border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              Notifications
            </CardTitle>
            <CardDescription>
              Configure how you receive notifications.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Email notifications</Label>
                <p className="text-sm text-muted-foreground">
                  Receive notifications via email
                </p>
              </div>
              <Switch defaultChecked onCheckedChange={() => handleSave("Email notifications")} />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Push notifications</Label>
                <p className="text-sm text-muted-foreground">
                  Receive push notifications in browser
                </p>
              </div>
              <Switch defaultChecked onCheckedChange={() => handleSave("Push notifications")} />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Weekly digest</Label>
                <p className="text-sm text-muted-foreground">
                  Get a weekly summary of activity
                </p>
              </div>
              <Switch onCheckedChange={() => handleSave("Weekly digest")} />
            </div>
          </CardContent>
        </Card>

        {/* Security Settings */}
        <Card className="glass border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Security
            </CardTitle>
            <CardDescription>
              Security and privacy settings.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Two-factor authentication</Label>
                <p className="text-sm text-muted-foreground">
                  Add an extra layer of security to your account
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-warning">
                  Not enabled
                </Badge>
                <Button variant="outline" size="sm">
                  Enable
                </Button>
              </div>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Session timeout</Label>
                <p className="text-sm text-muted-foreground">
                  Automatically log out after inactivity
                </p>
              </div>
              <Button variant="outline" size="sm">
                Configure
              </Button>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Login alerts</Label>
                <p className="text-sm text-muted-foreground">
                  Get notified of new login attempts
                </p>
              </div>
              <Switch defaultChecked onCheckedChange={() => handleSave("Login alerts")} />
            </div>
          </CardContent>
        </Card>

        {/* System Settings */}
        <Card className="glass border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              System
            </CardTitle>
            <CardDescription>
              Advanced system settings and maintenance.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Data export</Label>
                <p className="text-sm text-muted-foreground">
                  Export all your data in JSON format
                </p>
              </div>
              <Button variant="outline" size="sm" onClick={handleExport}>
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Clear cache</Label>
                <p className="text-sm text-muted-foreground">
                  Clear application cache and temporary files
                </p>
              </div>
              <Button variant="outline" size="sm" onClick={handleClearCache}>
                <Trash2 className="h-4 w-4 mr-2" />
                Clear
              </Button>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>System status</Label>
                <p className="text-sm text-muted-foreground">
                  Current system health and performance
                </p>
              </div>
              <Badge className="bg-success/10 text-success border-success/20">
                All systems operational
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* About */}
        <Card className="glass border-card-border">
          <CardHeader>
            <CardTitle>About</CardTitle>
            <CardDescription>
              Application information and version details.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="font-medium">Version</p>
                <p className="text-muted-foreground">v2.1.0</p>
              </div>
              <div>
                <p className="font-medium">Last updated</p>
                <p className="text-muted-foreground">2024-01-15</p>
              </div>
              <div>
                <p className="font-medium">License</p>
                <p className="text-muted-foreground">MIT License</p>
              </div>
              <div>
                <p className="font-medium">Support</p>
                <p className="text-muted-foreground">support@dashboard.com</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}